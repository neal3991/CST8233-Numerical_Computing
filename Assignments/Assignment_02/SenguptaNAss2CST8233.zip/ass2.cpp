/***************************************************************************************************************************************************************
* Filename:				ass2.cpp																															   *
* Version: 				1.0																																	   *
* Author:				Niladri Sengupta																													   *
* Student No:  			040777969																															   *
* Course Name/Number:	CST 8233 (Numerical Computing)																										   *
* Lab Sect: 			302																																	   *
* Assignment #:			02																																	   *
* Assignment name:		Least Squares Linear Regression Fit																								       *
* Due Date:				November 13, 2016																													   *
* Submission Date:		November 14, 2016																													   *
* Professor:			Andrew Tyler																														   *
* Purpose:				To understand and calculate the linear regression of a double exponential function (which resembles population over a course of time.  *
*						Equation: N = N0*exp(b*(exp(t*t))																									   *
* Note:					To read the file (example: WorldPopulation txt), it must be in the same folder as the source file and must be properly indented.	   *
****************************************************************************************************************************************************************/

/*To avoid any warnings in Visual Studio 2013*/
#define _CRT_SECURE_NO_WARNINGS 
/*Standard Libary Headers*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
/*Header to check memory leak. Uncomment if plug-in is installed*/
//#include <vld.h>

/*All the functions in this programs*/
void read();
void sub_menu();
void ie_calc(int choice);

/*Global Variables*/
FILE * txt_file;
int choice = 0;
int counter = 0;
char file_name[25];
double x = 0.0;
double y = 0.0;
double sum_x = 0.0;
double sum_y = 0.0;
double sum_x2 = 0.0;
double sum_xy = 0.0;
double x_sqr = 0.0;
double m = 0.0;
double b = 0.0;
double year = 0.0;
double final_y = 0.0;

/**************************************************************************************
* Function name:		main														  *
* Purpose:				Prints out the main menu of the program for the user to choose*
* In parameters:		none														  *
* Out parameters:		0 (if successful)											  *	
* Version:				1.0															  *
* Author:				Niladri Sengupta											  *
***************************************************************************************/
int main(void)
{
	while (true) //Running a continuous loop for the main menu
	{
		printf("\n\n*******************\n");
		printf("Exponential fit by Linear Regression\n");
		printf("1. Read Data from file\n");
		printf("2. Quit\n");
		printf("*******************\n");
		printf("Select an option: ");
		fflush(stdin);
		scanf_s("%d", &choice); //Choice of input from the user regarding the menu
		/*Using that choice for futher sub_menu or exiting the program*/
		switch (choice)
		{
		case 1: //Read the txt document and then present the sub_menu
			read(); 
			sub_menu();
			break;
		case 2: //Exit the program
			exit(0);
			break;
		default: //Non-valid input
			printf("Please enter a valid option!\n\n");
			break;
		}
	}
	return 0;
}
/********************************************************************
* Function name:	read											*
* Purpose:			Open file -> Then read and calculate the values *
* In parameters:	none											*
* Out parameters:	none											*
* Version:			1.0												*
* Author:			Niladri Sengupta								*
*********************************************************************/
void read(){
	int counter = 0; //Number of entires in the file
	printf("please enter the name of the file to open: ");
	scanf("%s", file_name);
	txt_file = fopen(file_name, "r");
	/*Checking the validity of the file*/
	if (txt_file == NULL){
		perror(file_name);
	}
	/*If file is valid then scanning each line of the file until the end of the file is reached*/
	if (txt_file != NULL){
		char line[128];
		/*Looping until the end of the file is reached*/
		while (fgets(line, sizeof line, txt_file) != NULL){
			counter++;
			sscanf(line, "%lf %lf", &x, &y);
			/*Following equations/functions are derived and/or taken from the ass2CST8233.docx file*/
			sum_x += exp(x*x);
			sum_y += log(y);
			sum_x2 += exp(x*x)*exp(x*x);
			sum_xy += exp(x*x) * log(y);
			x_sqr = sum_x * sum_x;
			/*Finding the value of "b" in the equation*/
			m = ((counter*sum_xy) - (sum_x*sum_y)) / (counter*sum_x2 - (x_sqr));
			/*Finding the value of "N0" in the equation*/
			b = ((sum_x2*sum_y) - (sum_xy*sum_x)) / ((counter*sum_x2) - x_sqr);
		}
		fclose(txt_file); //Close the file, since all the calcuations required are done
		printf("\n\nFILE OPENED FOR READING\n\nThere are %d records.\n\nFile read into memory\n\n", counter);
		printf("EXPONENTIAL FUNCTION\n");
		printf("Fit data to double exponential:   N = N0*exp(b*(exp(t*t))\n\n");
		printf("DOUBLE EXPONENTIAL:  y = %.3f*exp(%.4fexp(t*t))", exp(b), m);
	}

}

/************************************************************************************************
* Function name:	sub_menu																    *
* Purpose:			Gives the user choice for interpolation/extrapolation calculation or Quit	*
* In parameters:    void																	    *
* Out parameters:   void																		*
* Version:			1.0																		    *
* Author:			Niladri Sengupta															*
*************************************************************************************************/ 
void sub_menu(){
	bool while_loop = true;
	char sub_choice;
	while (while_loop)
	{
		printf("\n\n*******************\n");
		printf("Eponential Interpolation/Extrapolation\n");
		printf("1. Interpolation/Extrapolation of World Population\n");
		printf("2. Quit Interpolation/Extrapolation\n");
		printf("*******************\n");
		printf("Select an option: ");
		fflush(stdin);
		scanf("%c", &sub_choice);
		printf("Interpolation/Extrapolation of World Population\n");
		/*Switch statement between interpolation/extrapolation calculation or quit*/
		switch (sub_choice)
		{
		case '1'://Calculation
			ie_calc(choice);
			break;
		case '2'://Exit back to main menu
			while_loop = false;
			break;
		default://Unvalid choice
			printf("Please enter a valid option!\n\n");
			break;
		}
	}
}
/*****************************************************************************
* Function name:	ie_calc													 *
* Purpose:			To find out the population at a given year based on data *
* In parameters:	integer													 *
* Out parameters:	none													 *
* Version:			1.0														 *
* Author:			Niladri Sengupta										 *
******************************************************************************/
void ie_calc(int choice){
	/*Using the equation N = N0*exp(b*(exp(t*t)) to calculate the population at a given year*/
	float choice_year = 0.0; //Choice of year for calculation
	printf("Input a year (e.g. 2100): ");
	scanf("%f", &choice_year);
	final_y = exp(b)*(exp(m * exp(pow(choice_year / 1000, 2))));//Final equation
	printf("World Population at year %.0f =  %.4f billion", choice_year, final_y);//Final output
}